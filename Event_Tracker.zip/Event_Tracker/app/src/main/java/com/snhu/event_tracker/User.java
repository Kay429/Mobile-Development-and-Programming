package com.snhu.event_tracker;

public class User {
    public static User currentUser; // The currently active user

    private int userId;
    private boolean notificationAllowed;
    private String username;
    private String password;

    public User(int userId, boolean notificationAllowed, String username, String password) {
        this.userId = userId;
        this.notificationAllowed = notificationAllowed;
        this.username = username;
        this.password = password;
    }

    public int getUserId() {
        return userId;
    }

    public boolean isNotificationAllowed() {
        return notificationAllowed;
    }

    public void setNotificationAllowed(boolean notificationAllowed) {
        this.notificationAllowed = notificationAllowed;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

}
