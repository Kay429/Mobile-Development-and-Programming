
/*
 *  Credit goes to Callum Hill and his SQLite database tutorial
 *  Video is available here: https://youtu.be/4k1ZMpO9Zn0?si=rLa8kn8h3JU0ty17
 *
 */

package com.snhu.event_tracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.time.LocalDateTime;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.Objects;

public class SQLiteManager extends SQLiteOpenHelper {

    private static SQLiteManager sqLiteManager;

    // Database properties
    private static final String DB_NAME = "EventsDB";
    private static final int DB_VERSION = 2;
    private static final String USERS_TABLE_NAME = "Users";
    private static final String EVENTS_TABLE_NAME = "Events";
    private static final String COUNTER = "Counter";

    // Users Fields
    private static final String USERS_ID_FIELD = "User_Id";
    private static final String USERS_NOTIF_PERMISSION_FIELD = "Notifications_Allowed";
    private static final String USERS_USERNAME_FIELD = "Username";
    private static final String USERS_PASSWORD_FIELD = "Password";

    // Events Fields
    private static final String EVENTS_ID_FIELD = "Id";
    private static final String EVENTS_TITLE_FIELD = "Title";
    private static final String EVENTS_COLOR_FIELD = "Color";
    private static final String EVENTS_DATE_FIELD = "Date";
    private static final String EVENTS_TIME_FIELD = "Time";
    private static final String EVENTS_CREATED_FIELD = "Date_Created";
    private static final String EVENTS_DELETED_FIELD = "Date_Deleted";
    private static final String EVENTS_USER_ID = "User_Id";

    public SQLiteManager(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    // Returns new or existing SQLiteManager
    public static SQLiteManager instanceOfDatabase(Context context) {
        if (sqLiteManager == null) {
            sqLiteManager = new SQLiteManager(context);
        }
        return sqLiteManager;
    }

    @Override
    // Construct tables
    public void onCreate(SQLiteDatabase db) {
        StringBuilder sql;
        // Create User Table
        sql = new StringBuilder()
                .append("CREATE TABLE ")
                .append(USERS_TABLE_NAME)
                .append("(")
                .append(COUNTER)
                .append(" INTEGER PRIMARY KEY AUTOINCREMENT, ")
                .append(USERS_ID_FIELD)
                .append(" INT, ")
                .append(USERS_NOTIF_PERMISSION_FIELD)
                .append(" INT, ")
                .append(USERS_USERNAME_FIELD)
                .append(" TEXT, ")
                .append(USERS_PASSWORD_FIELD)
                .append(" TEXT)");

        db.execSQL(sql.toString());

        // Create Events Table
        sql = new StringBuilder()
                .append("CREATE TABLE ")
                .append(EVENTS_TABLE_NAME)
                .append("(")
                .append(COUNTER)
                .append(" INTEGER PRIMARY KEY AUTOINCREMENT, ")
                .append(EVENTS_ID_FIELD)
                .append(" INT, ")
                .append(EVENTS_TITLE_FIELD)
                .append(" TEXT, ")
                .append(EVENTS_COLOR_FIELD)
                .append(" TEXT, ")
                .append(EVENTS_DATE_FIELD)
                .append(" TEXT, ")
                .append(EVENTS_TIME_FIELD)
                .append(" TEXT, ")
                .append(EVENTS_CREATED_FIELD)
                .append(" TEXT, ")
                .append(EVENTS_DELETED_FIELD)
                .append(" TEXT, ")
                .append(EVENTS_USER_ID)
                .append(" INT)");

        db.execSQL(sql.toString());
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        /*switch (oldVersion) {
            case 1:
                db.execSQL("ALTER TABLE " + TABLE_NAME + " ADD COLUMN " + NEW_COLUMN + " TEXT");
            case 2:
                db.execSQL("ALTER TABLE " + TABLE_NAME + " ADD COLUMN " + NEW_COLUMN + " TEXT");
        }*/
    }

    public void addUserToDatabase(User user) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(USERS_ID_FIELD, user.getUserId());
        contentValues.put(USERS_NOTIF_PERMISSION_FIELD, user.isNotificationAllowed());
        contentValues.put(USERS_USERNAME_FIELD, user.getUsername());
        contentValues.put(USERS_PASSWORD_FIELD, user.getPassword());

        sqLiteDatabase.insert(USERS_TABLE_NAME,null, contentValues);
    }

    public void addEventToDatabase(Event event) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(EVENTS_ID_FIELD, event.getId());
        contentValues.put(EVENTS_TITLE_FIELD, event.getTitle());
        contentValues.put(EVENTS_COLOR_FIELD, event.getColor());
        contentValues.put(EVENTS_DATE_FIELD, getStringFromLocalDate(event.getDate()));
        contentValues.put(EVENTS_TIME_FIELD, getStringFromLocalTime(event.getTime()));
        contentValues.put(EVENTS_CREATED_FIELD, getStringFromLocalDateTime(event.getDateCreated()));
        contentValues.put(EVENTS_DELETED_FIELD, getStringFromLocalDateTime(event.getDateDeleted()));
        contentValues.put(EVENTS_USER_ID, event.getUserId());

        sqLiteDatabase.insert(EVENTS_TABLE_NAME,null, contentValues);
    }

    // Reads from database and populates eventArrayList with events belonging to the current user
    public void populateEventListArray() {
        Event.emptyArrayList();
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        // Get all events
        try (Cursor result = sqLiteDatabase.rawQuery("SELECT * FROM " + EVENTS_TABLE_NAME, null)) {
            if (result.getCount() != 0) {
                while (result.moveToNext()) {
                    // If event's userId matches currentUser's userId, add it to eventArrayList
                    if (result.getInt(8) == User.currentUser.getUserId()) {
                        int id = result.getInt(1);
                        String title = result.getString(2);
                        String color = result.getString(3);
                        String dateString = result.getString(4);
                        String timeString = result.getString(5);
                        String createdString = result.getString(6);
                        String deletedString = result.getString(7);
                        int userId = result.getInt(8);

                        LocalDate date = getLocalDateFromString(dateString);
                        LocalTime time = getLocalTimeFromString(timeString);
                        LocalDateTime created = getLocalDateTimeFromString(createdString);
                        LocalDateTime deleted = getLocalDateTimeFromString(deletedString);

                        Event event = new Event(id, title, color, date, time, created, deleted, userId);
                        Event.eventArrayList.add(event);
                    }
                }
            }
        }
    }

    // Search for a user with a matching username and password
    // If one is found, return it
    // Otherwise, return null
    public User verifyAndGetUser(String inUsername, String inPassword) {
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        // Search for a matching username
        try (Cursor result = sqLiteDatabase.rawQuery("SELECT * FROM " + USERS_TABLE_NAME + " WHERE " + USERS_USERNAME_FIELD + " =? ", new String[]{inUsername})) {
            if (result.getCount() != 0) {
                while (result.moveToNext()) {
                    // Check if passwords match
                    if (Objects.equals(result.getString(4), inPassword)) {
                        int id = result.getInt(1);
                        int intNotifPermission = result.getInt(2);
                        String username = result.getString(3);
                        String password = result.getString(4);

                        boolean notifPermission = (intNotifPermission == 1);

                        User user = new User(id, notifPermission, username, password);
                        return user;
                    }
                 }
             }
             return null;
        }
    }

    // If database already contains a user with given username, return false
    // Otherwise, return true
    public boolean isUsernameUnique(String inUsername) {
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        // Search for any users with username matching inUsername
        try (Cursor result = sqLiteDatabase.rawQuery("SELECT * FROM " + USERS_TABLE_NAME + " WHERE " + USERS_USERNAME_FIELD + " =? ", new String[]{inUsername})) {
            if (result.getCount() != 0) {
                return false;
            }
            else {
                return true;
            }
        }
    }

    public void updateUserInDatabase(User user) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(USERS_ID_FIELD, user.getUserId());
        contentValues.put(USERS_NOTIF_PERMISSION_FIELD, user.isNotificationAllowed());
        contentValues.put(USERS_USERNAME_FIELD, user.getUsername());
        contentValues.put(USERS_PASSWORD_FIELD, user.getPassword());

        sqLiteDatabase.update(USERS_TABLE_NAME, contentValues, USERS_ID_FIELD + " =? ", new String[]{String.valueOf(user.getUserId())});
    }

    public void updateEventInDatabase(Event event) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(EVENTS_ID_FIELD, event.getId());
        contentValues.put(EVENTS_TITLE_FIELD, event.getTitle());
        contentValues.put(EVENTS_COLOR_FIELD, event.getColor());
        contentValues.put(EVENTS_DATE_FIELD, getStringFromLocalDate(event.getDate()));
        contentValues.put(EVENTS_TIME_FIELD, getStringFromLocalTime(event.getTime()));
        contentValues.put(EVENTS_CREATED_FIELD, getStringFromLocalDateTime(event.getDateCreated()));
        contentValues.put(EVENTS_DELETED_FIELD, getStringFromLocalDateTime(event.getDateDeleted()));
        contentValues.put(EVENTS_USER_ID, event.getUserId());

        sqLiteDatabase.update(EVENTS_TABLE_NAME, contentValues, EVENTS_ID_FIELD + " =? " + " IN (SELECT " + EVENTS_USER_ID + " FROM " + EVENTS_TABLE_NAME + " WHERE " + EVENTS_USER_ID + " =? )", new String[]{String.valueOf(event.getId()), String.valueOf(event.getUserId())});

    }

    // Returns the number of users in database
    // Used to assign unique id numbers to new users
    public int getNumUsers() {
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        Cursor users = sqLiteDatabase.rawQuery("SELECT * FROM " + USERS_TABLE_NAME, null);

        return users.getCount();
    }

    private String getStringFromLocalTime(LocalTime time) {
        if (time == null) {
            return null;
        }
        else {
            return time.toString();
        }
    }
    private String getStringFromLocalDate(LocalDate date) {
        if (date == null) {
            return null;
        }
        else {
            return date.toString();
        }
    }
    private String getStringFromLocalDateTime(LocalDateTime dateTime) {
        if (dateTime == null) {
            return null;
        }
        else {
            return dateTime.toString();
        }
    }

    private LocalDate getLocalDateFromString(String string) {
        try {
            return LocalDate.parse(string);
        } catch (DateTimeParseException | NullPointerException e) {
            return null;
        }
    }
    private LocalTime getLocalTimeFromString(String string) {
        try {
            return LocalTime.parse(string);
        } catch (DateTimeParseException | NullPointerException e) {
            return null;
        }
    }
    private LocalDateTime getLocalDateTimeFromString(String string) {
        try {
            return LocalDateTime.parse(string);
        } catch (DateTimeParseException | NullPointerException e) {
            return null;
        }
    }
}
