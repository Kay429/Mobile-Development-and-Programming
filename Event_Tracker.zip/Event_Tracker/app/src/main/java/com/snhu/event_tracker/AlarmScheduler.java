package com.snhu.event_tracker;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.icu.util.Calendar;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class AlarmScheduler {

    public AlarmManager alarmManager;

    protected void initAlarmManager(Context context) {
        alarmManager = (AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
     }

    public void createNewAlarm(Context context, int userId, String eventName, LocalDateTime eventTime) {
        Intent intent = new Intent(context, AlarmReceiver.class);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
        String timeString = eventTime.format(formatter);

        // Intent will contain the associated event's name and time
        intent.putExtra("EVENT_NAME", eventName);
        intent.putExtra("EVENT_TIME", timeString);
        PendingIntent alarmIntent = PendingIntent.getBroadcast(context, eventName.hashCode() + userId, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        scheduleAlarm(alarmManager, alarmIntent, eventTime);
    }

    private void scheduleAlarm(AlarmManager alarmManager, PendingIntent alarmIntent, LocalDateTime eventTime) {
        // Set the alarm to start one day before the event
        Calendar calendar = Calendar.getInstance();
        calendar.clear();
        calendar.set(eventTime.getYear(), eventTime.getMonthValue() - 1, eventTime.getDayOfMonth() - 1, eventTime.getHour(), eventTime.getMinute());

            System.out.println("Alarm created");

        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), alarmIntent);
    }

    public void cancelAlarm(Context context, int userId, String eventName) {
        // Stop an alarm from going off
        Intent intent = new Intent(context, AlarmReceiver.class);
        PendingIntent alarmIntent = PendingIntent.getBroadcast(context, eventName.hashCode() + userId, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        System.out.println("Alarm canceled");

        if (alarmManager!= null) {
            alarmManager.cancel(alarmIntent);
        }
    }
}