
/*
 *  Credit goes to Callum Hill and his SQLite database tutorial
 *  Video is available here: https://youtu.be/4k1ZMpO9Zn0?si=rLa8kn8h3JU0ty17
 *
 */

package com.snhu.event_tracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;


public class EventListActivity extends AppCompatActivity {
    private ListView eventListView;
    private FloatingActionButton addEventButton;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.eventlist);
        initWidgets();
        loadFromDBToMemory();
        setEventAdapter();
        addEventButton.setOnClickListener(this::newEvent);
        eventListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            // Start the edit event activity when a list item is selected
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Event selectedEvent = (Event) eventListView.getItemAtPosition(position);
                Intent editEventIntent = new Intent(getApplicationContext(), EventEditActivity.class);
                editEventIntent.putExtra(Event.EVENT_EDIT_EXTRA, selectedEvent.getId());
                startActivity(editEventIntent);
            }
        });
    }

    @Override
    public void onDestroy() {
        System.out.println("onDestroy!!");
        super.onDestroy();
        Event.emptyArrayList();
        User.currentUser = null;
    }

    private void initWidgets() {
        eventListView = findViewById(R.id.item_list);
        addEventButton = findViewById(R.id.fab);
    }

    private void loadFromDBToMemory() {
        SQLiteManager sqLiteManager = SQLiteManager.instanceOfDatabase(this);
        sqLiteManager.populateEventListArray();
    }

    private void setEventAdapter(){
        EventAdapter eventAdapter = new EventAdapter(getApplicationContext(), Event.nonDeletedEvents());
        eventListView.setAdapter(eventAdapter);
    }

    // Start event edit activity for a new event
    private void newEvent(View view) {
        Intent newEventIntent = new Intent(this, EventEditActivity.class);
        startActivity(newEventIntent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        setEventAdapter();
    }
}
