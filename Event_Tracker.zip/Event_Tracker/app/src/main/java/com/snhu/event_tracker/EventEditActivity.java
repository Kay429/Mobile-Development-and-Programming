
/*
 *  Credit goes to Callum Hill and his SQLite database tutorial
 *  Video is available here: https://youtu.be/4k1ZMpO9Zn0?si=rLa8kn8h3JU0ty17
 *
 */

package com.snhu.event_tracker;

import static android.Manifest.permission.READ_PHONE_NUMBERS;
import static android.Manifest.permission.READ_SMS;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TimePicker;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Objects;

public class EventEditActivity extends AppCompatActivity{

    private Event selectedEvent; // Event selected for editing

    private AlarmScheduler alarmScheduler;

    private EditText titleEditText;
    private RadioGroup colorRadioGroup;
    private DatePicker datePicker;
    private TimePicker timePicker;

    private Button cancelButton;
    private Button confirmButton;
    private Button deleteButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_edit);
        initWidgets();
        cancelButton.setOnClickListener(this::cancelActivity);
        confirmButton.setOnClickListener(this::saveEvent);
        deleteButton.setOnClickListener(this::deleteEvent);
        checkForEditEvent(); // Determine if event is new or if editing existing event
        alarmScheduler = new AlarmScheduler();
        alarmScheduler.initAlarmManager(getApplicationContext());
    }

    private void initWidgets() {
        titleEditText = findViewById(R.id.edittext_eventname);
        colorRadioGroup = findViewById(R.id.radiogroup_color);
        datePicker = findViewById(R.id.datepicker);
        timePicker = findViewById(R.id.timepicker);
        cancelButton = findViewById(R.id.button_cancel);
        confirmButton = findViewById(R.id.button_confirm);
        deleteButton = findViewById(R.id.button_delete);
    }

    // Close activity
    private void cancelActivity(View view) {
        finish();
    }

    // Save event to eventArrayList and to database
    public void saveEvent(View view) {
        SQLiteManager sqLiteManager = SQLiteManager.instanceOfDatabase(this);

        // Obtain user-input from layout
        String title = String.valueOf(titleEditText.getText());
        int colorRadioId = colorRadioGroup.getCheckedRadioButtonId();
        String color = getColorString(colorRadioId);
        LocalDate date = LocalDate.of(datePicker.getYear(), datePicker.getMonth() + 1, datePicker.getDayOfMonth());
        LocalTime time = LocalTime.of(timePicker.getHour(), timePicker.getMinute());

        // Creating a new event
        if (selectedEvent == null) {
            LocalDateTime dateCreated = LocalDateTime.now();
            int userId = User.currentUser.getUserId();

            int id = Event.eventArrayList.size();

            Event newEvent = new Event(id, title, color, date, time, dateCreated, userId);
            Event.eventArrayList.add(newEvent);
            sqLiteManager.addEventToDatabase(newEvent);
        }
        // Editing an existing event
        else {
            selectedEvent.setTitle(title);
            selectedEvent.setColor(color);
            selectedEvent.setDate(date);
            selectedEvent.setTime(time);

            sqLiteManager.updateEventInDatabase(selectedEvent);
        }

        if (User.currentUser.isNotificationAllowed() && (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED)) {
            LocalDateTime dateTime = LocalDateTime.of(date, time);
            alarmScheduler.createNewAlarm(getApplicationContext(), User.currentUser.getUserId(), title, dateTime);
        }

        finish(); // Close activity
    }

    // Set selectedEvent's dateDeleted, which will indicate it should not be displayed anymore
    public void deleteEvent(View view) {
        selectedEvent.setDateDeleted(LocalDateTime.now());

        SQLiteManager sqLiteManager = SQLiteManager.instanceOfDatabase(this);
        sqLiteManager.updateEventInDatabase(selectedEvent);
        //sqLiteManager.populateEventListArray(); // Update

        if (User.currentUser.isNotificationAllowed() && (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED)) {
            alarmScheduler.cancelAlarm(getApplicationContext(), User.currentUser.getUserId(), selectedEvent.getTitle());
        }

        finish();
    }

    // Check if there is a selected event being edited
    // If so, initialize editing widgets to show selectedEvent's data
    // Else, hide delete button
    private void checkForEditEvent() {
        Intent previousIntent = getIntent();

        int passedEventId = previousIntent.getIntExtra(Event.EVENT_EDIT_EXTRA, -1);
        selectedEvent = Event.getEventForId(passedEventId);

        if (selectedEvent != null) {
            titleEditText.setText(selectedEvent.getTitle());

            int radioId = getRadioIdFromString(selectedEvent.getColor());
            if (radioId != -1) {
                colorRadioGroup.check(radioId);
            }

            LocalDate date = selectedEvent.getDate();
            datePicker.updateDate(date.getYear(), date.getMonthValue() - 1, date.getDayOfMonth());

            LocalTime time = selectedEvent.getTime();
            timePicker.setHour(time.getHour());
            timePicker.setMinute(time.getMinute());
        }
        else {
            deleteButton.setVisibility(View.INVISIBLE);
        }
    }

    // Given the id of a radio_button, return the corresponding string
    private String getColorString(int radioId) {
        if (radioId == R.id.radio_pink) {
            return "pink";
        }
        else if (radioId == R.id.radio_yellow) {
            return "yellow";
        }
        else if (radioId == R.id.radio_green) {
            return "green";
        }
        else if (radioId == R.id.radio_blue) {
            return "blue";
        }
        else if (radioId == R.id.radio_purple){
            return "purple";
        }
        else {
            return "";
        }
    }

    // Given a string, return the corresponding radio_button id
    private int getRadioIdFromString(String color) {
        if (Objects.equals(color, "pink")) {
            return R.id.radio_pink;
        }
        else if (Objects.equals(color, "yellow")) {
            return R.id.radio_yellow;
        }
        else if (Objects.equals(color, "green")) {
            return R.id.radio_green;
        }
        else if (Objects.equals(color, "blue")) {
            return R.id.radio_blue;
        }
        else if (Objects.equals(color, "purple")) {
            return R.id.radio_purple;
        }
        else {
            return -1;
        }
    }
}