package com.snhu.event_tracker;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;


public class AlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getStringExtra("EVENT_NAME") != null) {
            // Create a notification
            createNotification(context,
                    intent.getStringExtra("EVENT_NAME"),
                    intent.getStringExtra("EVENT_TIME"));
        }
    }

    private void createNotification(Context context, String eventName, String eventTime) {
        // If permission is given, build the notification
        if ((ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED)) {
            NotificationCompat.Builder builder = new NotificationCompat.Builder(context, MainActivity.CHANNEL_ID);

            String message = eventName + " - Event is tomorrow at " + eventTime + "!";

            builder.setContentTitle("Event Tomorrow!");
            builder.setContentText(message);
            builder.setSmallIcon(R.drawable.ic_launcher_background);
            builder.setAutoCancel(true);

            NotificationManagerCompat notifManagerCompat = NotificationManagerCompat.from(context);
            notifManagerCompat.notify(1, builder.build());

            System.out.println("Notification sent");
        }

    }
}
