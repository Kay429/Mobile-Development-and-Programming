
/*
 *  Credit goes to Callum Hill and his SQLite database tutorial
 *  Video is available here: https://youtu.be/4k1ZMpO9Zn0?si=rLa8kn8h3JU0ty17
 *
 */

package com.snhu.event_tracker;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;

import java.util.List;
import java.util.Objects;

public class EventAdapter extends ArrayAdapter<Event>

    {
    public EventAdapter(Context context, List<Event> events){
        super(context, 0, events);
    }

        @NonNull
        @Override
        // Updates listView items with event data
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            Event event = getItem(position);
            // If the ListView is not full yet,
            //   create a new event cell.
            // Otherwise, an existing cell will be recycled
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.event_cell, parent, false);
            }

            ConstraintLayout mainView = convertView.findViewById(R.id.mainVeiw);
            TextView title = convertView.findViewById(R.id.textview_eventtitle);
            TextView date = convertView.findViewById(R.id.textview_date);
            TextView time = convertView.findViewById(R.id.textview_time);

            // Set cell's text for title, date, and time
            title.setText(event.getTitle());
            date.setText(event.getDateFormatted());
            time.setText(event.getTimeFormatted());

            // Set cell's background color based on corresponding event's color value
            String color = event.getColor();
            if (Objects.equals(color, "pink")) {
                mainView.setBackgroundResource(R.color.pastel_pink);
            }
            else if (Objects.equals(color, "yellow")) {
                mainView.setBackgroundResource(R.color.pastel_yellow);
            }
            else if (Objects.equals(color, "green")) {
                mainView.setBackgroundResource(R.color.pastel_green);
            }
            else if (Objects.equals(color, "blue")) {
                mainView.setBackgroundResource(R.color.pastel_blue);
            }
            else if (Objects.equals(color, "purple")) {
                mainView.setBackgroundResource(R.color.pastel_purple);
            }
            else {
                mainView.setBackgroundResource(R.color.white);
            }

        return convertView;
    }
}
