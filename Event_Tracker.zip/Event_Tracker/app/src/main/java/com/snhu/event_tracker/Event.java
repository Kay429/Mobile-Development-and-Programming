
/*
 *  Credit goes to Callum Hill and his SQLite database tutorial
 *  Video is available here: https://youtu.be/4k1ZMpO9Zn0?si=rLa8kn8h3JU0ty17
 *
 */

package com.snhu.event_tracker;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class Event {

    // Holds all of the events currently being displayed
    public static ArrayList<Event> eventArrayList = new ArrayList<>();

    public static String EVENT_EDIT_EXTRA = "eventEdit";

    private int id;
    private String title;
    private String color;
    private LocalDate date;
    private LocalTime time;
    private LocalDateTime dateCreated;
    private LocalDateTime dateDeleted;
    private int userId; // Identifies the user the event belongs to

    public Event(int id, String title, String color, LocalDate date, LocalTime time, LocalDateTime dateCreated, LocalDateTime dateDeleted, int userId) {
        this.id = id;
        this.title = title;
        this.color = color;
        this.date = date;
        this.time = time;
        this.dateCreated = dateCreated;
        this.dateDeleted = dateDeleted;
        this.userId = userId;
    }

    // Constructor used for events that have not yet been deleted
    public Event(int id, String title, String color, LocalDate date, LocalTime time, LocalDateTime dateCreated, int userId) {
        this.id = id;
        this.title = title;
        this.color = color;
        this.date = date;
        this.time = time;
        this.dateCreated = dateCreated;
        this.dateDeleted = null;
        this.userId = userId;
    }

    // Given an event id, searches eventArrayList for the corresponding event and returns it
    public static Event getEventForId(int passedEventId) {
        for (Event event : eventArrayList) {
            if (event.id == passedEventId) {
                return event;
            }
        }
        return null;
    }

    // Parses eventArrayList for all nonDeleted events
    // Returns ArrayList of nonDeleted events
    public static ArrayList<Event> nonDeletedEvents() {
        ArrayList<Event> nonDeleted = new ArrayList<>();
        for (Event event : eventArrayList) {
            if (event.getDateDeleted() == null) {
                nonDeleted.add(event);
            }
        }
        return nonDeleted;
    }

    public static void emptyArrayList() {
        while (eventArrayList.size() != 0) {
            eventArrayList.remove(0);
        }
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public LocalDate getDate() {
        return date;
    }

    public String getDateFormatted() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM dd");
        String formattedDate = date.format(formatter);
        return formattedDate;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public LocalTime getTime() {
        return time;
    }

    public String getTimeFormatted() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
        String formattedTime = time.format(formatter);
        return formattedTime;
    }

    public void setTime(LocalTime time) {
        this.time = time;
    }

    public LocalDateTime getDateCreated() {
        return dateCreated;
    }

    public LocalDateTime getDateDeleted() {
        return dateDeleted;
    }

    public void setDateDeleted(LocalDateTime dateDeleted) {
        this.dateDeleted = dateDeleted;
    }

    public int getUserId() {
        return userId;
    }

}