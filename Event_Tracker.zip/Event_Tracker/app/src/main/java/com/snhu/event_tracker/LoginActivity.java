package com.snhu.event_tracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button logInButton;
    private Button newAccountButton;

    private TextView loginAssistantTextview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        initWidgets();
        logInButton.setOnClickListener(this::logIn);
        newAccountButton.setOnClickListener(this::createNewAccount);
    }

    private void initWidgets() {
        usernameEditText = findViewById(R.id.edittext_username);
        passwordEditText = findViewById(R.id.edittext_password);
        logInButton = findViewById(R.id.button_login);
        newAccountButton = findViewById(R.id.button_newaccount);
        loginAssistantTextview = findViewById(R.id.textview_loginAssistant);
    }

    private void logIn(View view) {
        SQLiteManager sqLiteManager = SQLiteManager.instanceOfDatabase(this);

        // Check to see if username and password are associated with a user
        // if not, notify the user that the username and/or password is incorrect
        // if a matching user is found, log them in
        User foundUser = sqLiteManager.verifyAndGetUser(usernameEditText.getText().toString(), passwordEditText.getText().toString());
        if (foundUser == null) {
            loginAssistantTextview.setVisibility(View.VISIBLE);
            loginAssistantTextview.setText(R.string.account_not_found);
            loginAssistantTextview.setTextColor(getColor(R.color.red));
        }
        else {
            User.currentUser = foundUser;
            Intent startApplicationIntent = new Intent(getApplicationContext(), EventListActivity.class);
            startActivity(startApplicationIntent);
        }
    }

    private void createNewAccount(View view) {
        SQLiteManager sqLiteManager = SQLiteManager.instanceOfDatabase(this);

        // Check if username is already in database
        // if not, create a new user
        // if so, notify user that the username is taken
        if (sqLiteManager.isUsernameUnique(usernameEditText.getText().toString())) {
            createNewUser(usernameEditText.getText().toString(), passwordEditText.getText().toString());

            loginAssistantTextview.setVisibility(View.VISIBLE);
            loginAssistantTextview.setText(R.string.new_account_login_prompt);
            loginAssistantTextview.setTextColor(getColor(R.color.light_blue));
        }
        else {
            loginAssistantTextview.setVisibility(View.VISIBLE);
            loginAssistantTextview.setText(R.string.account_already_exists);
            loginAssistantTextview.setTextColor(getColor(R.color.red));
        }
    }

    private void createNewUser(String username, String password) {
        SQLiteManager sqLiteManager = SQLiteManager.instanceOfDatabase(this);
        int userId = sqLiteManager.getNumUsers() + 1;
        boolean notifPermission = false; // By default, notifPermission is false

        User user = new User(userId, notifPermission, username, password);
        sqLiteManager.addUserToDatabase(user);
        User.currentUser = user;
        // Ask for permission to send notifications
        // This applies to the current user, not all of them
        Intent startApplicationIntent = new Intent(getApplicationContext(), NotifPermissionActivity.class);
        startActivity(startApplicationIntent);
    }
}
