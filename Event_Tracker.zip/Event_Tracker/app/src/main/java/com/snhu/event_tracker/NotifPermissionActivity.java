package com.snhu.event_tracker;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

import androidx.appcompat.app.AppCompatActivity;

public class NotifPermissionActivity extends AppCompatActivity {
    private Button proceedButton;
    private CheckBox permissionCheckbox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notif_permission);
        initWidgets();
        proceedButton.setOnClickListener(this::confirmChoice);
    }

    private void initWidgets() {
        proceedButton = findViewById(R.id.button_proceed);
        permissionCheckbox = findViewById(R.id.checkbox_permission);
    }

    // Set user's notification preferences based on their input
    private void confirmChoice(View view) {
        SQLiteManager sqLiteManager = SQLiteManager.instanceOfDatabase(this);
        User.currentUser.setNotificationAllowed(permissionCheckbox.isChecked());
        sqLiteManager.updateUserInDatabase(User.currentUser);
        User.currentUser = null;
        finish();
    }
}
