public class EventAdapter {
}
